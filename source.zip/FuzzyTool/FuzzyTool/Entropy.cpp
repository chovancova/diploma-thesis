#include "Fuzzyfication.h"
#include "TempFunctions.h"
#include <cmath>

